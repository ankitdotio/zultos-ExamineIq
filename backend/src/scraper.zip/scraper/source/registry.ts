import { SourceConfig } from "./source.types";

export const sscSource: SourceConfig = {
  id: "ssc",
  name: "Staff Selection Commission",
  authority: "SSC",
  category: "government-exams",

  baseUrl: "https://ssc.gov.in",

  allowedDomains: ["ssc.gov.in"],

  seedUrls: ["https://ssc.gov.in"],

  enabled: true,

  crawl: {
    maxDepth: 3,
    maxPagesPerRun: 100,
    delayMs: 1500,
  },
};
