export interface SourceConfig {
  id: string;
  name: string;
  authority: string;
  category: string;

  baseUrl: string;

  allowedDomains: string[];

  seedUrls: string[];

  enabled: boolean;

  crawl: {
    maxDepth: number;
    maxPagesPerRun: number;
    delayMs: number;
  };
}
