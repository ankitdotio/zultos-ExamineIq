import * as cheerio from "cheerio";

export interface DiscoveredLink {
  text: string;
  url: string;
}

export const discoverLinks = (
  html: string,
  baseUrl: string,
): DiscoveredLink[] => {
  const $ = cheerio.load(html);

  const links: DiscoveredLink[] = [];

  $("a[href]").each((_, element) => {
    const href = $(element).attr("href");

    if (!href) return;

    try {
      const url = new URL(href, baseUrl).href;

      const text = $(element).text().replace(/\s+/g, " ").trim();

      links.push({
        text,
        url,
      });
    } catch {
      // Ignore malformed URLs
    }
  });

  return links;
};
