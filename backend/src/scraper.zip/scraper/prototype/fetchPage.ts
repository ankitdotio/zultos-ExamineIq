export const fetchPage = async (url: string): Promise<string> => {
  const response = await fetch(url, {
    headers: {
      "User-Agent": "ExamineIQBot/1.0",
    },
    signal: AbortSignal.timeout(10_000),
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch ${url}: ${response.status}`);
  }

  const contentType = response.headers.get("content-type");

  if (!contentType?.includes("text/html")) {
    throw new Error(`Expected HTML, received ${contentType}`);
  }

  return response.text();
};
