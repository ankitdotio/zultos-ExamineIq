const isPdf = (url: string) => url.toLowerCase().includes(".pdf");

const looksLikeNotification = (text: string) => {
  const value = text.toLowerCase();

  return (
    value.includes("notification") ||
    value.includes("notice") ||
    value.includes("advertisement")
  );
};
export const downloadPdf = async (url: string): Promise<Buffer> => {
  const response = await fetch(url, {
    headers: {
      "User-Agent": "ExamineIQBot/1.0",
    },
    signal: AbortSignal.timeout(30_000),
  });

  if (!response.ok) {
    throw new Error(`PDF download failed: ${response.status}`);
  }

  const contentType = response.headers.get("content-type");

  if (contentType && !contentType.includes("application/pdf")) {
    throw new Error(`Expected PDF but received ${contentType}`);
  }

  const arrayBuffer = await response.arrayBuffer();

  return Buffer.from(arrayBuffer);
};
